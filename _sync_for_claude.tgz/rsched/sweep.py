"""Run concurrent RPent episodes at several concurrency levels.

    python -m rsched.sweep configs/p1_fifo_sweep.yaml [--levels 1 2 4] [--dry-run]

The model services (Pi0.5, SAM3, and Molmo for Flash) must already be running
(see ``scripts/launch_services.sh``); loading them takes minutes, so they are
shared across levels. For each level this script starts fresh proxies and a GPU
sampler, keeps N episodes in flight (closed loop) or launches them as a Poisson
process, and writes everything under ``results/<name>/<stamp>/N<level>_r<rep>/``:

    manifest.json           config, git commits, host and GPU info, timings
    proxy_vla.jsonl         per-request trace from the VLA proxy
    proxy_sam3.jsonl        per-request trace from the SAM3 proxy
    gpu.jsonl               GPU memory / utilization samples
    history.jsonl           work of each finished episode (history scheduling)
    traces/episode_*.jsonl  per-episode tool calls, client RPCs, outcome
    episodes/<id>/          RPent's own output directory per episode
    logs/                   stdout/stderr of every process
"""

from __future__ import annotations

import argparse
import itertools
import json
import os
import platform
import random
import shlex
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rsched.launch_order import RULES as LAUNCH_RULES  # noqa: E402
from rsched.launch_order import STATIC_RULES as STATIC_LAUNCH_RULES  # noqa: E402
from rsched.launch_order import ESTIMATES as LAUNCH_ESTIMATES  # noqa: E402
from rsched.launch_order import (  # noqa: E402
    cold_tasks,
    jit_pick,
    launch_estimates,
    load_history,
    plan_estimate,
    static_order,
    task_key,
)

REPO_ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def load_env_file(path: Path) -> list[str]:
    """Load KEY=VALUE lines from env/.env without overriding the shell.

    ``scripts/*.sh`` source this file, but ``python -m rsched.sweep`` run directly
    did not, so episodes started without the planner API key.
    """
    if not path.exists():
        return []
    os.environ.setdefault("RS_ROOT", str(REPO_ROOT))
    loaded = []
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.removeprefix("export ").partition("=")
        key, value = key.strip(), value.strip().strip("'\"")
        if key and value and key not in os.environ:
            os.environ[key] = os.path.expandvars(value)
            loaded.append(key)
    return loaded


def drop_broken_hf_transfer() -> bool:
    """Unset ``HF_HUB_ENABLE_HF_TRANSFER`` when ``hf_transfer`` is not installed.

    Some images (RunPod) set it in every new shell, tmux included. Episodes sync
    their memory (Flash plans) from Hugging Face at start, and with the flag
    but no package every download raises, so every episode crashed.
    """
    import importlib.util

    flag = os.environ.get("HF_HUB_ENABLE_HF_TRANSFER", "").strip().lower()
    if flag in ("", "0", "false", "no", "off") or importlib.util.find_spec("hf_transfer") is not None:
        return False
    os.environ.pop("HF_HUB_ENABLE_HF_TRANSFER")
    print("unset HF_HUB_ENABLE_HF_TRANSFER: hf_transfer is not installed, downloads would fail")
    return True


PLANNER_KEY_ENV = {"claude_code": "ANTHROPIC_API_KEY", "codex": "OPENAI_API_KEY"}


def preflight_planner(cfg: dict) -> None:
    """One cheap request through RPent's own checker before launching any episode."""
    r = cfg["rpent"]
    if "command" in r or r.get("planner") not in ("claude_code", "codex", "api"):
        return  # custom command (tests) or a planner the checker does not cover
    cmd = [sys.executable, "-c", "import sys; from rpent.cli.check_llm import main; sys.exit(main())",
           "--planner", r["planner"]]
    if r.get("model"):
        cmd += ["--model", r["model"]]
    print("preflight: checking planner credentials with rpent-check-llm ...", flush=True)
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=REPO_ROOT)
    print("  " + (proc.stdout + proc.stderr).strip().replace("\n", "\n  "), flush=True)
    if proc.returncode != 0:
        key = PLANNER_KEY_ENV.get(r["planner"], "the planner's API key")
        sys.exit(f"preflight FAILED: the planner cannot authenticate. Set {key} in env/.env "
                 f"(currently {'set' if os.environ.get(key) else 'NOT set'}) and retry. "
                 "Skip with --skip-preflight.")


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def git_rev(path: Path) -> str | None:
    try:
        rev = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "HEAD"], capture_output=True, text=True, check=True
        ).stdout.strip()
        dirty = subprocess.run(
            ["git", "-C", str(path), "status", "--porcelain"], capture_output=True, text=True
        ).stdout.strip()
        return rev + ("-dirty" if dirty else "")
    except Exception:
        return None


def gpu_info() -> list[str]:
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"],
            capture_output=True, text=True, check=True,
        ).stdout
        return [line.strip() for line in out.strip().splitlines()]
    except Exception:
        return []


def _read(path: str) -> str | None:
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def _cgroup_cpu(root: str = "/sys/fs/cgroup") -> tuple[str | None, str]:
    """(quota, cpu.stat text). cgroup v2 has ``cpu.max``; v1 (RunPod, older
    Docker) has ``cpu.cfs_quota_us``/``cpu.cfs_period_us`` under ``cpu/`` or
    ``cpu,cpuacct/``. The quota is reported in v2 form: "<quota> <period>"."""
    quota = _read(f"{root}/cpu.max")
    if quota is not None:
        return quota, _read(f"{root}/cpu.stat") or ""
    for sub in ("cpu", "cpu,cpuacct"):
        q, per = _read(f"{root}/{sub}/cpu.cfs_quota_us"), _read(f"{root}/{sub}/cpu.cfs_period_us")
        if q is not None and per is not None:
            return ("max" if q == "-1" else q) + " " + per, _read(f"{root}/{sub}/cpu.stat") or ""
    return None, ""


def cpu_info(root: str = "/sys/fs/cgroup") -> dict:
    """CPU visibility vs. quota. In containers ``os.cpu_count()`` is the host's
    count, so OpenMP/torch size their thread pools for cores the cgroup does
    not grant; ``cpu.stat`` throttle counters show the cost."""
    quota, stat = _cgroup_cpu(root)
    return {
        "os_cpu_count": os.cpu_count(),
        "affinity": len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "cgroup_cpu_max": quota,
        "cgroup_cpu_stat": dict(
            (k, int(v)) for k, v in (line.split() for line in stat.splitlines() if line.strip())
        ),
        "thread_env": {k: os.environ[k] for k in THREAD_VARS if k in os.environ},
    }


THREAD_VARS = ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS")


def wait_http(url: str, timeout_s: float = 30.0) -> None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200:
                    return
        except Exception:
            time.sleep(0.2)
    raise TimeoutError(f"{url} not ready after {timeout_s}s")


def check_backend(endpoint: str) -> None:
    """Call RPent's built-in ``healthz`` on a service (works through any proxy)."""
    body = json.dumps({"method": "healthz", "args": [], "kwargs": {}, "session_id": None}).encode()
    req = urllib.request.Request(
        endpoint.rstrip("/") + "/call", data=body, headers={"Content-Type": "application/json"}
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=10) as r:
        payload = json.loads(r.read())
    if not payload.get("ok"):
        raise RuntimeError(f"{endpoint} healthz failed: {payload}")


@dataclass
class EpisodeSpec:
    episode_id: str
    suite: str
    task: int
    seed: int


def episode_pool(cfg: dict) -> list[tuple[str, int, int]]:
    ep = cfg["episodes"]
    if "list" in ep:
        return [(e["suite"], int(e["task"]), int(e.get("seed", 0))) for e in ep["list"]]
    pool = list(itertools.product(ep["suites"], ep["tasks"], ep.get("seeds", [0])))
    if ep.get("shuffle_seed") is not None:
        random.Random(ep["shuffle_seed"]).shuffle(pool)
    return pool


SCHED_MODES = ("none", "intent_srpt", "intent_lrpt", "history_srpt", "history_lrpt")


def scheduling(cfg: dict) -> dict:
    """``scheduling: {mode, costs}`` with defaults; checks the proxies can act on it.

    Any mode other than ``none`` sends ``X-RS-Priority``, which only the proxy's
    ``priority`` policy reads. With ``mode: none`` a ``priority`` proxy serves in
    arrival order, so one config can run every mode through the same code path.
    """
    sched = {"mode": "none", "costs": {}, **(cfg.get("scheduling") or {})}
    if sched["mode"] not in SCHED_MODES:
        raise ValueError(f"scheduling.mode {sched['mode']!r}; choose from {SCHED_MODES}")
    if sched["mode"] != "none":
        wrong = [svc for svc in ("vla", "molmo") if svc in cfg["services"]
                 and cfg["services"][svc].get("policy", "fifo") != "priority"]
        if wrong:
            raise ValueError(f"scheduling.mode={sched['mode']} needs policy: priority on {wrong}")
    return sched


def launch_config(cfg: dict) -> dict:
    """``launch: {rule, slack, shuffle, seed, plans_dir}`` with defaults.

    ``shuffle`` puts the episode list in a random order per repeat (seed + repeat)
    before the rule applies, so ``rule: given`` is a random-order baseline and
    two rules at the same repeat start from the same order.
    """
    lc = {"rule": "given", "slack": 1.0, "shuffle": False, "seed": 0, "plans_dir": None,
          "estimate": "plan", "history_file": None, "cold_fraction": 0.0, "cold_seed": 0,
          **(cfg.get("launch") or {})}
    if lc["rule"] not in LAUNCH_RULES:
        raise ValueError(f"launch.rule {lc['rule']!r}; choose from {LAUNCH_RULES}")
    if lc["estimate"] not in LAUNCH_ESTIMATES:
        raise ValueError(f"launch.estimate {lc['estimate']!r}; choose from {LAUNCH_ESTIMATES}")
    if lc["estimate"] != "plan" and not lc["history_file"]:
        raise ValueError(f"launch.estimate={lc['estimate']} needs launch.history_file")
    if not 0.0 <= float(lc["cold_fraction"]) <= 1.0:
        raise ValueError("launch.cold_fraction must be in [0, 1]")
    return lc


def flash_plans_dir(cfg: dict) -> Path:
    """Directory with ``<suite>_t<task>_plan.json``: config, or RPent's own memory sync.

    ``python -m robots.libero.memory sync`` downloads the corpus into the cache
    every episode reads (a no-op when it is already there) and prints its root.
    """
    explicit = (cfg.get("launch") or {}).get("plans_dir")
    if explicit:
        return Path(explicit)
    extra = [str(x) for x in cfg["rpent"].get("extra_args", [])]
    version = extra[extra.index("--memory-version") + 1] if "--memory-version" in extra else "GPT_5.5_xhigh"
    proc = subprocess.run([sys.executable, "-m", "robots.libero.memory", "sync", "--memory-version", version,
                           "--planner", "flash"], capture_output=True, text=True, cwd=REPO_ROOT)
    if proc.returncode != 0:
        raise RuntimeError(f"memory sync failed:\n{proc.stdout[-2000:]}{proc.stderr[-2000:]}")
    root = Path(proc.stdout.strip().splitlines()[-1])
    for name in ("flash", "task_card"):
        if (root / name).is_dir():
            return root / name
    raise FileNotFoundError(f"no Flash plans under {root}")


def plan_estimates(cfg: dict, pool: list[tuple[str, int, int]]) -> dict[tuple[str, int], float]:
    """Planned work (s) per (suite, task) in the pool, priced like ``scheduling.costs``."""
    plans = flash_plans_dir(cfg)
    costs = (cfg.get("scheduling") or {}).get("costs") or {}
    return {(su, t): plan_estimate(plans, su, t, costs) for su, t, _ in pool}


def episode_estimates(cfg: dict, pool: list[tuple[str, int, int]]) -> tuple[dict, dict]:
    """Launch estimates per (suite, task) for ``launch.estimate``, plus what was used.

    The plan is always computed (history and hybrid are rescaled to it); the
    cold set is drawn once from the pool's tasks, the same for every repeat.
    """
    lc = launch_config(cfg)
    n_total = int(cfg["episodes_per_level"])
    cells = [pool[i % len(pool)] for i in range(n_total)]
    weights: dict[tuple[str, int], int] = {}
    for su, t, _ in cells:
        weights[(su, t)] = weights.get((su, t), 0) + 1
    plan = plan_estimates(cfg, pool)
    history = load_history(Path(lc["history_file"])) if lc["history_file"] else None
    cold = cold_tasks([task_key(su, t) for su, t in plan], float(lc["cold_fraction"]), int(lc["cold_seed"]))
    est = launch_estimates(plan, history, lc["estimate"], cold, weights)
    info = {"estimate": lc["estimate"], "cold_tasks": sorted(cold),
            "history_tasks": sorted(set(history or {}) & {task_key(*t) for t in plan}),
            "plan_s": {task_key(*t): v for t, v in plan.items()},
            "estimate_s": {task_key(*t): v for t, v in est.items()}}
    return est, info


# ---------------------------------------------------------------------------
# one level
# ---------------------------------------------------------------------------


class SweepAborted(RuntimeError):
    pass


def count_tool_calls(trace: Path) -> int:
    if not trace.exists():
        return 0
    with trace.open() as fh:
        return sum(1 for line in fh if '"type":"tool"' in line)


# Planner failures that will hit every later episode too; matched in the episode log.
FATAL_PATTERNS = {
    "billing_error": "billing error",
    "Credit balance is too low": "billing error",
    "authentication_failed": "authentication failure",
    "Not logged in": "authentication failure",
}


def fatal_planner_error(log: Path) -> str | None:
    if not log.exists():
        return None
    tail = log.read_text(errors="replace")[-20000:]
    return next((kind for pat, kind in FATAL_PATTERNS.items() if pat in tail), None)


def print_log_tail(path: Path, n: int = 25) -> None:
    if not path.exists():
        return
    lines = path.read_text(errors="replace").splitlines()[-n:]
    print(f"  ----- tail {path} -----")
    for line in lines:
        print("  | " + line)
    print("  -----", flush=True)


class Level:
    def __init__(self, cfg: dict, level: int, rep: int, out: Path, dry_run: bool,
                 estimates: dict[tuple[str, int], float] | None = None) -> None:
        self.cfg, self.level, self.rep, self.out, self.dry_run = cfg, level, rep, out, dry_run
        self.estimates = estimates or {}
        # Abort after this many consecutive episodes that exit without a single tool call.
        self.fail_fast = 0 if dry_run else int(cfg.get("fail_fast", 2))
        self.consecutive_failures = 0
        self.procs: list[subprocess.Popen] = []
        self.logs = out / "logs"
        self.logs.mkdir(parents=True, exist_ok=True)
        (out / "traces").mkdir(exist_ok=True)
        (out / "episodes").mkdir(exist_ok=True)

    def _spawn(self, name: str, cmd: list[str], env: dict | None = None) -> subprocess.Popen:
        log = open(self.logs / f"{name}.log", "w")
        log.write("$ " + shlex.join(cmd) + "\n")
        log.flush()
        if self.dry_run:
            print("[dry-run]", shlex.join(cmd))
        p = subprocess.Popen(
            cmd if not self.dry_run else [sys.executable, "-c", "pass"],
            stdout=log, stderr=subprocess.STDOUT, env={**os.environ, **(env or {})},
            cwd=REPO_ROOT, start_new_session=True,
        )
        return p

    def start_infra(self) -> dict[str, str]:
        """Start one proxy per service plus the GPU sampler; return client endpoints."""
        endpoints = {}
        for svc, scfg in self.cfg["services"].items():
            port = free_port()
            cmd = [
                sys.executable, "-m", "rsched.proxy",
                "--name", svc, "--listen", str(port), "--backend", scfg["backend"],
                "--policy", scfg.get("policy", "fifo"),
                "--max-inflight", str(scfg.get("max_inflight", 1)),
                "--aging", str(scfg.get("aging", 0.0)),
                "--log", str(self.out / f"proxy_{svc}.jsonl"),
            ]
            self.procs.append(self._spawn(f"proxy_{svc}", cmd))
            endpoints[svc] = f"http://127.0.0.1:{port}"
        if self.cfg.get("gpu_sampler", True):
            cmd = [sys.executable, "-m", "rsched.nvml", "--interval",
                   str(self.cfg.get("gpu_interval_s", 0.5)), "--log", str(self.out / "gpu.jsonl")]
            self.procs.append(self._spawn("gpu_sampler", cmd))
        if not self.dry_run:
            for svc, url in endpoints.items():
                wait_http(url + "/rs/stats")
                check_backend(url)
        return endpoints

    def episode_cmd(self, spec: EpisodeSpec, endpoints: dict[str, str]) -> list[str]:
        r = self.cfg["rpent"]
        cmd = list(r.get("command", [sys.executable, "-m", "rsched.launch"]))
        cmd += ["--robot", r.get("robot", "libero"),
                "--suite", spec.suite, "--task", str(spec.task), "--seed", str(spec.seed),
                "--planner", r["planner"],
                "--output-dir", str(self.out / "episodes" / spec.episode_id)]
        if r.get("model"):
            cmd += ["--model", r["model"]]
        if r.get("libero_type"):
            cmd += ["--libero-type", r["libero_type"]]
        if r.get("cuda_device") is not None:
            cmd += ["--cuda-device", str(r["cuda_device"])]
        if "vla" in endpoints:
            cmd += ["--vla-endpoint", endpoints["vla"]]
        if "sam3" in endpoints:
            cmd += ["--sam3-endpoint", endpoints["sam3"]]
        if "molmo" in endpoints:
            cmd += ["--molmo-endpoint", endpoints["molmo"]]
        cmd += [str(x) for x in r.get("extra_args", [])]
        return cmd

    def run(self) -> dict[str, Any]:
        endpoints = self.start_infra()
        pool = episode_pool(self.cfg)
        n_total = int(self.cfg["episodes_per_level"])
        timeout_s = float(self.cfg.get("episode_timeout_s", 3600))
        arrival = self.cfg.get("arrival", {"mode": "closed"})
        rng = random.Random(arrival.get("seed", 0))

        lc = launch_config(self.cfg)
        cells = [pool[i % len(pool)] for i in range(n_total)]
        if lc["shuffle"]:
            random.Random(int(lc["seed"]) * 1000 + self.rep).shuffle(cells)
        specs = [EpisodeSpec(f"N{self.level}r{self.rep}e{i:03d}", *c) for i, c in enumerate(cells)]
        est = {s.episode_id: self.estimates.get((s.suite, s.task), 0.0 if self.dry_run else None)
               for s in specs}
        if lc["rule"] != "given" and any(v is None for v in est.values()):
            raise ValueError(f"launch.rule={lc['rule']} needs a launch estimate for every episode")
        if lc["rule"] in STATIC_LAUNCH_RULES:
            specs = [specs[i] for i in static_order([est[s.episode_id] or 0.0 for s in specs],
                                                     lc["rule"], self.level)]
        pending = list(specs)
        running: dict[str, tuple[subprocess.Popen, float]] = {}
        finished: list[dict] = []
        launched: list[dict] = []

        def next_spec(now_t: float) -> EpisodeSpec:
            if lc["rule"] != "jit_lpt":
                return pending.pop(0)
            k = jit_pick(now_t, [est[s.episode_id] for s in pending],
                         [(est[e], ts) for e, (_, ts) in running.items()],
                         [(est[f["episode"]], f["wall_s"]) for f in finished], self.level, lc["slack"])
            return pending.pop(k)
        next_arrival = time.time()
        t0 = time.time()

        sched = scheduling(self.cfg)

        def launch(spec: EpisodeSpec) -> None:
            # episode_env (e.g. thread caps) reaches rpent and the env_server it spawns.
            env = {k: str(v) for k, v in (self.cfg.get("episode_env") or {}).items()}
            env.update({"RS_EPISODE_ID": spec.episode_id, "RS_TRACE_DIR": str(self.out / "traces"),
                        "RS_SCHED": sched["mode"], "RS_COSTS": json.dumps(sched["costs"]),
                        "RS_HISTORY_FILE": str(self.out / "history.jsonl")})
            p = self._spawn(f"episode_{spec.episode_id}", self.episode_cmd(spec, endpoints), env)
            running[spec.episode_id] = (p, time.time())
            launched.append({"episode": spec.episode_id, "t": time.time(), "estimate_s": est[spec.episode_id]})
            print(f"  start {spec.episode_id} {spec.suite} task={spec.task} seed={spec.seed} "
                  f"(running={len(running)})", flush=True)

        try:
            while pending or running:
                now_t = time.time()
                if arrival["mode"] == "closed":
                    while pending and len(running) < self.level:
                        launch(next_spec(now_t))
                else:  # poisson: rate in episodes/minute, capped at `level` in flight
                    while pending and now_t >= next_arrival and len(running) < self.level:
                        launch(next_spec(now_t))
                        next_arrival += rng.expovariate(arrival["rate_per_min"] / 60.0)
                for eid, (p, ts) in list(running.items()):
                    rc = p.poll()
                    if rc is None and now_t - ts > timeout_s:
                        os.killpg(p.pid, signal.SIGTERM)
                        rc = "timeout"
                    if rc is not None:
                        running.pop(eid)
                        n_tools = count_tool_calls(self.out / "traces" / f"episode_{eid}.jsonl")
                        finished.append({"episode": eid, "returncode": rc, "wall_s": now_t - ts,
                                         "tool_calls": n_tools})
                        log_path = self.logs / f"episode_{eid}.log"
                        fatal = fatal_planner_error(log_path)
                        if fatal:
                            status = f"  <-- PLANNER {fatal.upper()}"
                        elif n_tools == 0:
                            status = "  <-- CRASHED (no tool calls)"
                        elif rc != 0:
                            status = "  (exit != 0: task unsolved or planner stopped, e.g. max turns)"
                        else:
                            status = ""
                        print(f"  done  {eid} rc={rc} tools={n_tools} wall={now_t - ts:.1f}s{status}",
                              flush=True)
                        if fatal or n_tools == 0:
                            print_log_tail(log_path)
                        if fatal:
                            raise SweepAborted(
                                f"planner {fatal} (e.g. out of API credit or bad key); every further "
                                "episode would fail. Fix it, then rerun the remaining levels with --levels")
                        self.consecutive_failures = self.consecutive_failures + 1 if n_tools == 0 else 0
                        if self.consecutive_failures >= self.fail_fast > 0:
                            raise SweepAborted(
                                f"{self.consecutive_failures} episodes in a row exited without a single "
                                "tool call; aborting to save time and API cost (see log above)")
                time.sleep(0.5)
        except SweepAborted as exc:
            aborted = str(exc)
        else:
            aborted = None
        finally:
            for p, _ in running.values():
                os.killpg(p.pid, signal.SIGTERM)
            self.stop_infra()
        return {"t_start": t0, "t_end": time.time(), "episodes": finished,
                "specs": [s.__dict__ for s in specs], "endpoints": endpoints, "aborted": aborted,
                "launch": lc, "launched": launched}

    def stop_infra(self) -> None:
        for p in self.procs:
            if p.poll() is None:
                os.killpg(p.pid, signal.SIGTERM)
        for p in self.procs:
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--levels", type=int, nargs="*", help="override concurrency levels")
    ap.add_argument("--repeats", type=int, help="override repeats")
    ap.add_argument("--repeat-index", type=int, default=0,
                    help="number the first repeat k (directories N<level>_r<k>); for drivers")
    ap.add_argument("--sched", choices=SCHED_MODES, help="override scheduling.mode")
    ap.add_argument("--launch", choices=LAUNCH_RULES, help="override launch.rule")
    ap.add_argument("--estimate", choices=LAUNCH_ESTIMATES, help="override launch.estimate")
    ap.add_argument("--cold", type=float, help="override launch.cold_fraction")
    ap.add_argument("--history-file", help="override launch.history_file")
    ap.add_argument("--episodes", type=int, help="override episodes_per_level (e.g. a short warm-up)")
    ap.add_argument("--out", default=None, help="output root (default results/<name>/<stamp>)")
    ap.add_argument("--dry-run", action="store_true", help="print commands, run nothing")
    ap.add_argument("--skip-preflight", action="store_true", help="skip the planner credential check")
    args = ap.parse_args(argv)

    loaded = load_env_file(REPO_ROOT / "env" / ".env")
    if loaded:
        print(f"loaded from env/.env: {', '.join(sorted(loaded))}")
    drop_broken_hf_transfer()
    cfg = yaml.safe_load(Path(args.config).read_text())
    if args.sched:
        cfg["scheduling"] = {**(cfg.get("scheduling") or {}), "mode": args.sched}
    sched = scheduling(cfg)
    if args.launch:
        cfg["launch"] = {**(cfg.get("launch") or {}), "rule": args.launch}
    if args.estimate:
        cfg["launch"] = {**(cfg.get("launch") or {}), "estimate": args.estimate}
    if args.cold is not None:
        cfg["launch"] = {**(cfg.get("launch") or {}), "cold_fraction": args.cold}
    if args.history_file:
        cfg["launch"] = {**(cfg.get("launch") or {}), "history_file": args.history_file}
    if args.episodes:
        cfg["episodes_per_level"] = args.episodes
    lc = launch_config(cfg)
    estimates, est_info = {}, {}
    if cfg.get("launch") and not args.dry_run:
        estimates, est_info = episode_estimates(cfg, episode_pool(cfg))
        print(f"launch: rule={lc['rule']} estimate={lc['estimate']} shuffle={lc['shuffle']}; "
              f"{len(estimates)} tasks, {min(estimates.values()):.0f}-{max(estimates.values()):.0f} s; "
              f"history for {len(est_info['history_tasks'])}, cold {len(est_info['cold_tasks'])}")
    if not (args.dry_run or args.skip_preflight):
        preflight_planner(cfg)
    levels = args.levels or cfg["concurrency"]
    repeats = args.repeats or cfg.get("repeats", 1)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    root = Path(args.out) if args.out else REPO_ROOT / "results" / cfg["name"] / stamp
    root.mkdir(parents=True, exist_ok=True)
    (root / "config.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))

    for rep in range(args.repeat_index, args.repeat_index + repeats):
        for level in levels:
            out = root / f"N{level}_r{rep}"
            out.mkdir(parents=True, exist_ok=True)
            print(f"== level N={level} repeat={rep} -> {out}", flush=True)
            manifest = {
                "name": cfg["name"], "level": level, "repeat": rep, "config": cfg,
                "rsched_commit": git_rev(REPO_ROOT),
                "rpent_commit": git_rev(REPO_ROOT / "third_party" / "RPent"),
                "host": platform.node(), "platform": platform.platform(),
                "python": sys.version.split()[0], "gpus": gpu_info(),
                "episode_env": cfg.get("episode_env") or {}, "scheduling": sched,
                "launch_estimates": est_info, "cpu_start": cpu_info(),
            }
            manifest.update(Level(cfg, level, rep, out, args.dry_run, estimates).run())
            manifest["cpu_end"] = cpu_info()
            (out / "manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
            if manifest["aborted"]:
                sys.exit(f"SWEEP ABORTED at N={level}: {manifest['aborted']}")
    print(f"all levels done: {root}")


if __name__ == "__main__":
    main()
