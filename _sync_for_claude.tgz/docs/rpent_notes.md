# RPent behaviour notes

Facts about the pinned RPent that this project's design or measurements depend
on. Each is checked against the source at the pinned commit; paths are relative
to `third_party/RPent`.

- **Pinned commit:** `ef70215` (2026-10-13). When the submodule is bumped,
  re-check every row and update this commit hash.
- Add a row only when a design decision or a measurement depends on it.

## Service model

| fact | source | why it matters here |
|---|---|---|
| RPC servers run on `ThreadingHTTPServer` (one thread per request) | `rpent/utils/rpc/http_rpc.py:207` | concurrent requests reach the model at once |
| Non-read-only RPC methods hold an exclusive write lock | `rpent/utils/rpc/rpc_facade.py:150` | `vla.predict` is serialized |
| Lock waiters wake via `notify_all` and race | `rpent/utils/rwlock.py:59` | RPent's order is not FIFO; the proxy's `fifo` policy defines the baseline, `passthrough` measures RPent as is |
| `vla.predict` is registered as a mutating method | `rpent/robots/components/vla_facade_base.py:56` | serialized as above |
| `sam3.segment` is read-only | `rpent/robots/components/sam3_server.py:125` | SAM3 requests run concurrently; little queueing expected |
| Pi0.5 inference is batched (`predict_action_batch`); clients send batch 1 | `rpent/robots/components/pi05_vla_server.py:259` | a batching baseline can merge requests in the proxy |
| Pi0.5 is built on CPU, then moved to GPU | `rpent/robots/components/pi05_vla_server.py:227` | ~13 GB host RAM peak at load (WSL2 OOM) |
| Client timeouts: `vla.predict` 120 s, `sam3.segment` 120 s | `rpent/robots/components/vla_client_base.py:23`, `rpent/robots/components/sam3_client.py:45` | very high concurrency can time out; the proxy logs failures |

## Tools and VLA demand

| fact | source | why it matters here |
|---|---|---|
| One `vla.predict` returns one action chunk; LIBERO chunk = 5 actions | `robots/libero/tools.py:169`, `rpent/robots/components/pi05_vla_server.py:93` | VLA call count = chunks executed |
| `pi0_pick` loops chunks until success or `max_chunks` (default 24) | `robots/libero/tools.py:206`, `:210` | the planner writes an upper bound on VLA demand before execution: the core signal |
| `pi0_doubled` loops up to `max_chunks` (default 20) | `robots/libero/tools.py:293` | same |
| Scripted tools (`move_to`, `move_pose`, `rotate_*`, `release`, `set_gripper`) drive the simulator only | `robots/libero/tools.py` | no GPU-model demand; simulator time |
| All planners execute tools through `Toolkit.execute_tool`, in a thread | `rpent/tools/toolkit.py:215`, `rpent/planner/base.py:86` | one hook in `rsched/launch.py` sees every tool call and its arguments |

## Runtime and episodes

| fact | source | why it matters here |
|---|---|---|
| Each episode spawns its own `env_server` with `MUJOCO_GL=egl` | `robots/libero/robot_spec.py:385`, `:419` | simulator cost scales with N; needs EGL and libGL |
| `finalize_run` is optional; LIBERO does not set it. The CLI reads `toolkit.solved()` and builds `RunFinalizationContext` only when the hook is set | `rpent/robots/robot_spec.py:88`, `robots/libero/robot_spec.py:126`, `rpent/cli/main.py:635`, `rpent/cli/main.py:700` | `rsched.launch` installs a no-op finalizer so that path runs. Success is `LiberoToolkit._solved`, set from `record.terminated` (`robots/libero/toolkit.py:168`, `:235`) |
| Claude Code planner stats include `total_cost_usd` | `rpent/planner/claude_code.py:632` | copied into the outcome record's `stats` |
| `--memory-version auto` falls back to `GPT_5.5_xhigh` for unmapped models | `robots/libero/memory.py:76` | configs pin it explicitly |

## Flash Mode (plan-once regime)

| fact | source | why it matters here |
|---|---|---|
| `--planner flash` replays a stored plan; no LLM decisions | `docs/source-en/rst_source/guides/flash.rst` | zero API cost; VLA/simulator-bound workload |
| `--planner flash` requires `--molmo-endpoint`; any other planner rejects it | `robots/libero/robot_spec.py:294` | the sweep forwards the endpoint only when a molmo service is configured |
| Flash with `--memory-version auto` selects `GPT_5.5_xhigh` and does not read `--model` | `robots/libero/memory.py:84`, `rpent/planner/base.py:295` | the flash config pins that version and sets no model |
| `molmo.ground` is a read-only RPC, but `generate` runs under the server's own lock; Molmo2 loads in bf16 | `rpent/robots/components/molmo_server.py:109`, `:121`, `:148` | requests are serialized anyway, so the proxy queues them (fifo, 1 in flight) to make the wait visible; the weights share the GPU with Pi0.5 and SAM3 |
| Flash replay calls `molmo.ground` and reads observations between tool calls, not inside them | `robots/libero/flash/replay.py:123`, `:134`, `:202` | `breakdown.py` charges RPCs outside tools to their service, not to `planner` |
| `_parse_point` expects `coords="<id> <x> <y>"`; our Molmo2-8B emits `"<image> <id> <x> <y>"`, so the point became `(id, x)` | `rpent/robots/components/molmo_server.py:51`, `:55` | every anchor sat on the left image edge (G2 N=1: 0/16 solved). `rsched.molmo_server` swaps in a parser for both formats; `launch_services.sh` starts that |
| Molmo2-8B localizes plan anchors; needs its own venv (newer `transformers`) | `docs/source-en/rst_source/guides/flash.rst` | a third GPU model; extra service to launch |
| Replay order: one Molmo survey per anchor (segment-located anchors use the `segment` tool), then per Molmo anchor a `move_to` and a wrist re-grounding; plan `segment` steps are skipped; each `set_gripper` is followed by a held-object grounding; a failed pick is retried up to `PICK_ATTEMPTS`=3 with the same prompt | `robots/libero/flash/replay.py:30`, `:270`-`:345`, `:395`-`:430` | `rsched/intent.py` counts a program's work the same way; retries add work on top of the plan |
| Replay reads the program through `replay.load(root, plan_name)` before its first model call | `robots/libero/flash/replay.py:221`, `:486` | `rsched.launch` wraps `load` to start the remaining-work count |
| The plan's anchors file lists each anchor's locator; object suites ground every anchor with `segment`, so they make no Molmo calls | Hugging Face `RLinf/RPent-memory`, `libero/GPT_5.5_xhigh/flash/*_anchors.json` | G3 task choice; Molmo load comes from the 10, goal, and spatial suites |
| In real Flash runs the `Tool.__call__` hook captured no `pi0_pick` result (G2 traces: `result: {}`) | G2 traces | remaining-work counting uses `vla.predict` RPCs and prompts, not the pick's own result |
| Plans for 78 LIBERO-PRO tasks under `GPT_5.5_xhigh/flash/`; `goal_swap_t0` and `10_swap_t9` absent | same | task list for Flash sweeps |
| Supported suites | `robots/libero/robot_spec.py:62` | config validation |
